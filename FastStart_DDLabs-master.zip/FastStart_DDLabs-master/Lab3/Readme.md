# Lab 3 - Executing an Optimization Model from outside DSX Local

>Using the new Decision Framework API (Beta in Q1/2018)

This feature allow external entities to execute pre-built optimization models in DSX Local's CPLEX server.								


